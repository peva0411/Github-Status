﻿var app = angular.module('githubStatusApp', []);

app.controller('MainCtrl',['$scope', 'EventService', function($scope, eventService) {
    $scope.getMostRecentEvent = function(user) {
        eventService.getEvents(user)
            .then(function(events) {
            $scope.event = events[0];
        }).catch(function(reason) {
            alert(reason);
        });
    };

    $scope.getMostRecentEvent('peva0411');

}]);

app.factory('EventService', ['$q', "$http", function ($q, $http) {

    var apiEndpoint = "https://api.github.com/users/";

    return {
        getEvents: function(user) {
            var defered = $q.defer();

            var requestUrl = apiEndpoint + user + '/events';

            $http.get(requestUrl)
                .success(function(data) {
                    defered.resolve(data);
                })
                .error(function(reason) {
                    defered.reject(reason);
                });

            return defered.promise;
        }
    };
}]);